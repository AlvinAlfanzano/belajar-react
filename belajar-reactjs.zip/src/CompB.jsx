import React from 'react'
import CompC from './CompC'

const CompB = () => {
  return (
    <>
    <CompC/>
    <h1>Comp B</h1>
    </>
  )
}

export default CompB;
